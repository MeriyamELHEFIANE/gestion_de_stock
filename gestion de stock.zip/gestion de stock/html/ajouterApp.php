<?php
require_once("approvisionnement.php");
extract($_POST);
$p=new approvisionnement($numApp,$dateApp,$idf);
$p->save();
 header("location:formligneA.php");
?>