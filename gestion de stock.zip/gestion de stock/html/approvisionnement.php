<?php
require_once("DAO.php");
class approvisionnement{
    public $numApp;
    public $dateApp;
    public $idf;
    function __construct($numApp,$dateApp,$idf){
        $this->numApp=$numApp;
        $this->dateApp=$dateApp;
        $this->idf=$idf;
    }
    function __get($prop){
        switch ($prop) {
            case 'numApp':  return $this->numApp;  break;
            case 'dateApp': return $this->dateApp;   break;
            case 'idf':return $this->idf;break;    
        }
    }
    function save(){
		DAO::enregistrerApp($this->numApp,$this->dateApp,$this->idf);
	}
	static function listeApp(){
		return DAO::listeApp();
	}
	static function  getApp($numApp){
		return DAO::getApp($numApp);
	}
	function update(){
		DAO::modifierApp($this->numApp,$this->dateApp,$this->idf);
	}
	static function  supprimerApp($numApp){
		DAO::supprimerApp($numApp);
	}
    }
    
