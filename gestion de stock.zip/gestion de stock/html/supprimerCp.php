<?php
	require_once("categorie.php");
	$idcp=$_GET['idcp'];
	categorie::supprimerCategorie($idcp);
	header("location:listeCategorie.php");

?>