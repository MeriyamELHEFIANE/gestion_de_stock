<?php
	require_once("fr.php");
	$idf=$_GET['idf'];
	fr::supprimer($idf);
	header("location:listeFrs.php");

?>