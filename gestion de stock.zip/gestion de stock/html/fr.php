<?php
require_once("DAO.php");
class fr{
    public $nom;
    public $tel;
    public $email;
    public $adr;
    function __construct($idf,$n,$t,$e,$a){
        $this->idf=$idf;
        $this->nom=$n;
        $this->tel=$t;
        $this->email=$e;
        $this->adr=$a;
    }
    function _get($c){
        switch ($c) {
            case 'idf':  return $this->idf;  break;
            case 'nom':
                return $this->nom;
                break;
            case 'tel':
                return $this->tel;
                break;
            case 'email':
                return $this->email;
                break;
            case 'adr':
                return $this->adr;
                break;   
        }
    }
    function save(){
		DAO::enregistrerFrs($this->nom,$this->tel,$this->email,$this->adr);
	}
	static function listeFrs(){
		return DAO::listeFrs();
	}
	static function  getFrs($idf){
		return DAO::getFrs($idf);
	}
	function update(){
		DAO::modifierFrs($this->idf,$this->nom,$this->tel,$this->email,$this->adr);
	}
	static function  supprimer($idf){
		DAO::supprimerFrs($idf);
	}
    }
    
