<?php
require_once("DAO.php");
class commande{
    public $numCom;
    public $date;
    public $idc;
    function __construct($numCom,$date,$idc){
        $this->numCom=$numCom;
        $this->date=$date;
        $this->idc=$idc;
    }
    function __get($prop){
        switch ($prop) {
            case 'numCom':  return $this->numCom;  break;
            case 'date': return $this->date;   break;
            case 'idc':return $this->idc;break;    
        }
    }
    function save(){
		DAO::enregistrerCommande($this->numCom,$this->date,$this->idc);
	}
	static function listeCommande(){
		return DAO::listeCommande();
	}
    static function liste(){
		return DAO::liste();
	}
	static function  getCommande($numCom){
		return DAO::getCommande($numCom);
	}
	function update(){
		DAO::modifierCommande($this->numCom,$this->date,$this->idc);
	}
	static function  supprimerCommande($numCom){
		DAO::supprimerCommande($numCom);
	}
    }
    
