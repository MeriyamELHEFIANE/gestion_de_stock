<?php
require_once("ligneApp.php");
extract($_POST);
$p=new ligneApp($ida,$ref,$numApp,$qteApp);
$p->save();
 header("location:ligneApp.php");
?>