<?php
	require_once("produit.php");
	extract($_POST);
	$p=new produit($ref,$lib,$pu,$qte,$pa,$pv,$idcp);
	$p->update();
	header("location:listeProduits.php");
?>