<?php
require_once("commande.php");
extract($_POST);
$p=new commande($numCom,$date,$idc);
$p->save();
 header("location:formligne.php");
?>