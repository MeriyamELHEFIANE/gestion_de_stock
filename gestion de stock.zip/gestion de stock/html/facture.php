<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="facture.css">
    <title>Facture</title>
</head>
<body>

    <form action="">
    <div class="header__logo">
       <h1><img src="img/logo.png" alt=""> <br>  Facture</h1>
        <h6>Bienvenue  <br>
        Marrakech Plaza <br>
        Marrakech-Safi <br>
        Maroc</h6>
        
        <?php 
		$con = mysqli_connect("localhost","root","","gestion_de_stock"); 
		$sel=mysqli_query($con,"SELECT *FROM client join commande join ligneCmde join produit join categorie;");
	?>	
        <table  class="table-bordered">
        <thead>
                <tr>
                <th> <h2>la reference de produit &ensp;</h2> </th> <br>
                <th> <h2>la categorie &ensp;</h2> </th> <br>
                <th> <h2>libelle &ensp;</h2></th>          
                <th> <h2> Prix  &ensp;</h2></th>
                </tr>
                </thead>
        <?php
                $i=1;
                    foreach($sel as $items) {                                     
                  ?>                 
                <tr>
                  <!--<td><=$Statment->num?></td>-->
                    <td><?= $items['ref']; ?></td>
                    <td><?= $items['cp']; ?></td>
                    <td><?= $items['lib']; ?></td>
                    <td><?= $items['pu']; ?></td>
                </tr>
                <?php } ?>
                </tfoot>
         </table>
                    <label for="inputText" class="col-form-label" name="total"><h3>&ensp; &ensp; &ensp; &ensp; &ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;Total TTC</h3></label>
                    <input type="text" name="totalttc" class="form-control"><br>
</div>
    </form>
    <ul class="bienvenue"><h3>Bienvenue cher(e) client(e).</h3></ul>

</body>
</html>