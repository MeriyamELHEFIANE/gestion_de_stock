<?php
	require_once("fr.php");
	extract($_POST);
	$p=new fr($idf,$nom,$tel,$email,$adr);
	$p->update();
	header("location:listeFrs.php");
?>