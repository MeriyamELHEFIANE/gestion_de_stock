<?php 
require_once("DAO.php");
class administrateur{
	
	private $nom;
	private $login;
	private $password;
	function __construct($n,$l,$p){
		$this->nom=$n;
		$this->login=$l;
		$this->password=$p;
	}

	function __get($prop){
		switch ($prop) {
			case 'nom':  return $this->nom;  break;
			case 'login':  return $this->login;  break;
			case 'password':  return $this->password;  break;
		}

	}
	function estUnAdmin(){
			return DAO::authentification($this->login,$this->password);
		}

}

?>