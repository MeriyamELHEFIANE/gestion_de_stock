<?php
require_once("client.php");
extract($_POST);
$p=new client($id,$nom,$tel,$email,$adr);
$p->save();
header("location:listeClients.php");
?>