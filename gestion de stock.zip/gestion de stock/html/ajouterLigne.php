<?php
require_once("ligneCmde.php");
extract($_POST);
$p=new ligneCmde($idl,$ref,$numCom,$qtePro);
$p->save();
 header("location:pdf.php");
?>