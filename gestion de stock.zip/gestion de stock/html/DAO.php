<?php
class DAO{
    static function getPDO(){
        return new PDO("mysql:host=localhost;dbname=gestion_de_stock","root","");
    }
	//produit:
    static function  enregistrerProduits($ref,$lib,$pu,$qte,$pa,$pv,$idcp){
        $pdo=DAO::getPDO();
        $res=$pdo->prepare("INSERT into produit(ref,lib,pu,qte,pa,pv,idcp)values(?,?,?,?,?,?,?);");
        $res->execute(array($ref,$lib,$pu,$qte,$pa,$pv,$idcp));
    }
	static function  supprimerProduits($ref){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("delete from produit where ref=?;");
		$res->execute(array($ref));
	}	
	static function  modifierProduit($ref,$lib,$pu,$qte,$pa,$pv,$idcp){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("update produit set ref=? ,lib=?,pu=?,qte=?,pa=?,pv=? where idcp=?;");
		$res->execute(array($ref,$lib,$pu,$qte,$pa,$pv,$idcp));
	}
	static function  listeProduits(){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("select * from produit;");
		$res->execute(array());
		$lst=[];
		while($row=$res->fetch()){
			$lst[]=new produit($row["ref"],$row["lib"],$row["pu"],$row["qte"],$row["pa"],$row["pv"],$row["idcp"]);
		}
		return $lst;
	}
	

	static function  getProduits($ref){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("select * from produit where ref=?;");
		$res->execute(array($ref));
		if($row=$res->fetch()){
			return new produit($row["ref"],$row["lib"],$row["pu"],$row["qte"],$row["pa"],$row["pv"],$row["idcp"]);
		}
		return null;
	}
	//categorie:
	static function  enregistrerCategorie($idcp,$cp){
        $pdo=DAO::getPDO();
        $res=$pdo->prepare("INSERT into categorie(cp)values(?);");
        $res->execute(array($cp));
    }
	static function  supprimerCategorie($idcp){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("DELETE FROM categorie WHERE idcp=?;");
		$res->execute(array($idcp));
	}	
	static function  modifierCategorie($idcp,$cp){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("update categorie set cp=?  where idcp=?;");
		$res->execute(array($cp,$idcp));
	}
	static function  listeCategorie(){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("select * from categorie;");
		$res->execute(array());
		$lst=[];
		while($row=$res->fetch()){
			$lst[]=new categorie($row["idcp"],$row["cp"]);
		}
		return $lst;
	}
	

	static function  getCategorie($idcp){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("select * from categorie where idcp=?;");
		$res->execute(array($idcp));
		if($row=$res->fetch()){
			return new categorie($row["idcp"],$row["cp"]);
		}
		return null;
	}
	//client:
	static function  enregistrerClients($nom,$tel,$email,$adr){
        $pdo=DAO::getPDO();
        $res=$pdo->prepare("INSERT into client(nom,tel,email,adr)values(?,?,?,?);");
        $res->execute(array($nom,$tel,$email,$adr));
    }
	static function  supprimerClient($idc){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("DELETE FROM client WHERE idc=?;");
		$res->execute(array($idc));
	}	
	static function  modifierClient($idc,$nom,$tel,$email,$adr){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("update client set nom=? ,tel=?,email=?,adr=? where idc=?;");
		$res->execute(array($nom,$tel,$email,$adr,$idc));
	}
	static function  listeClients(){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("select * from client;");
		$res->execute(array());
		$lst=[];
		while($row=$res->fetch()){
			$lst[]=new client($row["idc"],$row["nom"],$row["tel"],$row["email"],$row["adr"]);
		}
		return $lst;
	}
	static function authentification($login,$password){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("select * from administrateur where login=? and password =?;");
		$res->execute(array($login,$password));
		if($row=$res->fetch()) {
			return True;
		}else{
		return False;
		}

    }

	static function  getClients($idc){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("select * from client where idc=?;");
		$res->execute(array($idc));
		if($row=$res->fetch()){
			return new client($row["idc"],$row["nom"],$row["tel"],$row["email"],$row["adr"]);
		}
		return null;
	}
	//frs:
	static function  enregistrerFrs($n,$t,$e,$a){
        $pdo=DAO::getPDO();
        $res=$pdo->prepare("INSERT into fr(nom,tel,email,adr)values(?,?,?,?);");
        $res->execute(array($n,$t,$e,$a));
    }
	static function  supprimerFrs($idf){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("delete from fr where idf=?;");
		$res->execute(array($idf));
	}	
	static function  modifierFrs($idf,$n,$t,$e,$a){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("update fr set nom=? ,tel=?,email=?,adr=? where idf=?;");
		$res->execute(array($n,$t,$e,$a,$idf));
	}
	static function  listeFrs(){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("select * from fr;");
		$res->execute(array());
		$lst=[];
		while($row=$res->fetch()){
			$lst[]=new fr($row["idf"],$row["nom"],$row["tel"],$row["email"],$row["adr"]);
		}
		return $lst;
	}
	static function  getFrs($idf){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("select * from fr where idf=?;");
		$res->execute(array($idf));
		if($row=$res->fetch()){
			return new fr($row["idf"],$row["nom"],$row["tel"],$row["email"],$row["adr"]);
		}
		return null;
	}
	//commande:
	static function  enregistrerCommande($numCom,$date,$idc){
        $pdo=DAO::getPDO();
        $res=$pdo->prepare("INSERT into commande values(?,?,?);");
        $res->execute(array($numCom,$date,$idc));
    }
	static function  supprimerCommande($numCom){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("delete from commande where numCom=?;");
		$res->execute(array($numCom));
	}	
	static function  modifierCommande($numCom,$date,$idc){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("update commande set date=?,idc=?,idp=?,qtePro=? where numCom=?;");
		$res->execute(array($numCom,$date,$idc));
	}
	static function  listeCommande(){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("select * from commande;");
		$res->execute(array());
		$lst=[];
		while($row=$res->fetch()){
			$lst[]=new commande($row["numCom"],$row["date"],$row["idc"]);
		}
		return $lst;
	}
	static function  getCommande($numCom){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("SELECT *FROM client join commande join ligneCmde where numCom=?;");
		$res->execute(array($numCom));
		if($row=$res->fetch()){
			return new commande($row["numCom"],$row["date"],$row["idc"],$row["nom"],$row["tel"],$row["email"],$row["adr"],$row["ref"],$row["qtePro"]);
		}
		return null;
	}
	//ligneCommande
	static function  enregistrerLigne($ref,$numCom,$qtePro){
        $pdo=DAO::getPDO();
        $res=$pdo->prepare("INSERT into lignecmde(ref,numCom,qtePro) values(?,?,?);");
        $res->execute(array($ref,$numCom,$qtePro));
    }
	static function  listeLigne(){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("select * from ligencmde;");
		$res->execute(array());
		$lst=[];
		while($row=$res->fetch()){
			$lst[]=new ligneCmde($row["idl"],$row["ref"],$row["numCom"],$row["qtePro"]);
		}
		return $lst;
	}
	static function  getLigne($idl){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("select * from ligencmde where idl=?;");
		$res->execute(array($idl));
		if($row=$res->fetch()){
			return new ligneCmde($row["idl"],$row["ref"],$row["numCom"],$row["qtePro"]);
		}
		return null;
	}
	//app:
	static function  enregistrerApp($numApp,$dateApp,$idf){
        $pdo=DAO::getPDO();
        $res=$pdo->prepare("INSERT into App values(?,?,?);");
        $res->execute(array($numApp,$dateApp,$idf));
    }
	static function  supprimerApp($numApp){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("delete from App where numApp=?;");
		$res->execute(array($numApp));
	}	
	static function  modifierApp($numApp,$dateApp,$idf){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("update App set dateApp=?,idc=?,idp=?,qtePro=? where numApp=?;");
		$res->execute(array($numApp,$dateApp,$idf));
	}
	static function  listeApp(){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("select * from App;");
		$res->execute(array());
		$lst=[];
		while($row=$res->fetch()){
			$lst[]=new approvisionnement($row["numApp"],$row["dateApp"],$row["idc"]);
		}
		return $lst;
	}
	static function  getApp($numApp){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("select * from App where numApp=?;");
		$res->execute(array($numApp));
		if($row=$res->fetch()){
			return new approvisionnement($row["numApp"],$row["dateApp"],$row["idc"]);
		}
		return null;
	}
	//ligne app:
	static function  enregistrerLignea($ref,$numApp,$qteApp){
        $pdo=DAO::getPDO();
        $res=$pdo->prepare("INSERT into ligneApp(ref,numApp,qteApp) values(?,?,?);");
        $res->execute(array($ref,$numApp,$qteApp));
    }
	static function  listeLignea(){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("select * from lignecmde;");
		$res->execute(array());
		$lst=[];
		while($row=$res->fetch()){
			$lst[]=new ligneApp($row["ida"],$row["ref"],$row["numApp"],$row["qteApp"]);
		}
		return $lst;
	}
	static function  getLignea($idl){
		$pdo=DAO::getPDO();
		$res=$pdo->prepare("select * from ligneApp where ida=?;");
		$res->execute(array($idl));
		if($row=$res->fetch()){
			return new ligneApp($row["ida"],$row["ref"],$row["numApp"],$row["qteApp"]);
		}
		return null;
	}

}


?>