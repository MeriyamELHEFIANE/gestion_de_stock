<?php
require_once("DAO.php");
class ligneCmde{
    public $idl;
    public $ref;
    public $numCom;
    public $qtePro;
    function __construct($idl,$ref,$numCom,$qtePro){
        $this->idl=$idl;
        $this->ref=$ref;
        $this->numCom=$numCom;
        $this->qtePro=$qtePro;
    }
    function __get($prop){
        switch ($prop) {
            case 'idl':  return $this->idl;  break;
            case 'ref': return $this->ref;   break;
            case 'numCom':return $this->numCom;break;  
            case 'qtePro':return $this->qtePro;break;    
        }
    }
    function save(){
		DAO::enregistrerLigne($this->ref,$this->numCom,$this->qtePro);
	}
	static function listeLigne(){
		return DAO::listeLigne();
	}
	static function  getLigne($idl){
		return DAO::getLigne($idl);
	}
	function update(){
		DAO::modifierLigne($this->idl,$this->ref,$this->numCom,$this->qtePro);
	}
	static function  supprimerLigne($idl){
		DAO::supprimerLigne($idl);
	}
    }
    
