<?php
require_once("DAO.php");
class produit{
    public $ref;
    public $lib;
    public $pu;
    public $qte;
    public $pa;
    public $pv;
    public $idcp;
    function __construct($ref,$lib,$pu,$qte,$pa,$pv,$idcp){
        $this->ref=$ref;
        $this->lib=$lib;
        $this->pu=$pu;
        $this->qte=$qte;
        $this->pa=$pa;
        $this->pv=$pv;
        $this->idcp=$idcp;
    }
    function _get($c){
        switch ($c) {
            case 'ref':
                return $this->ref;
                break;
            case 'lib':
                return $this->lib;
                break;
            case 'pu':
                return $this->pu;
                break;
            case 'qte':
                return $this->qte;
                break;   
            case 'pa':
                return $this->pa;
                break;
            case 'pv':
                return $this->pv;
                break;
            case 'idcp':
                return $this->idcp;
                break; 
        }
    }
    function save(){
		DAO::enregistrerProduits($this->ref,$this->lib,$this->pu,$this->qte,$this->pa,$this->pv,$this->idcp);
	}
	static function listeProduits(){
		return DAO::listeProduits();
	}
	static function  getProduits($ref){
		return DAO::getProduits($ref);
	}
	function update(){
		DAO::modifierProduit($this->ref,$this->lib,$this->pu,$this->qte,$this->pa,$this->pv,$this->idcp);
	}
	static function  supprimer($ref){
		DAO::supprimerProduits($ref);
	}
    }
    
