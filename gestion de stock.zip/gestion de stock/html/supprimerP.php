<?php
	require_once("produit.php");
	$ref=$_GET['ref'];
	produit::supprimer($ref);
	header("location:listeProduits.php");

?>