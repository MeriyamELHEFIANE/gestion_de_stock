<?php
require_once("DAO.php");
class categorie{
    public $idcp;
    public $cp;
    function __construct($idcp,$cp){
        $this->idcp=$idcp;
        $this->cp=$cp;
    }
    function __get($prop){
        switch ($prop) {
            case 'idcp':  return $this->idcp;  break;
            case 'cp': return $this->cp;   break;   
        }
    }
    function save(){
		DAO::enregistrerCategorie($this->idcp,$this->cp);
	}
	static function listeCategorie(){
		return DAO::listeCategorie();
	}
	static function  getCategorie($idcp){
		return DAO::getCategorie($idcp);
	}
	function update(){
		DAO::modifierCategorie($this->idcp,$this->cp);
	}
	static function  supprimerCategorie($idcp){
		DAO::supprimerCategorie($idcp);
	}
    }
    
