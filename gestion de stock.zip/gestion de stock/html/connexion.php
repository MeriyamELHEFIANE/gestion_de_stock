<?php
require_once("administrateur.php");
	extract($_POST);
	$a=new administrateur("",$login,$password);
	if($a->estUnAdmin()){
			session_start();
			$_SESSION['login']=$login;
			header("location:index.php");
	}else{
		header("location:login.php");
	}


?>