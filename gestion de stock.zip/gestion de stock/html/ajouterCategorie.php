<?php
require_once("categorie.php");
extract($_POST);
$p=new categorie($idcp,$cp);
$p->save();
header("location:listeCategorie.php");
?>