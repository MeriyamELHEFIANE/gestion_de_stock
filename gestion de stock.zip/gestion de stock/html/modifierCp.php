<?php
	require_once("categorie.php");
	extract($_POST);
	$p=new categorie($idcp,$cp);
	$p->update();
	header("location:listeCategorie.php");
?>