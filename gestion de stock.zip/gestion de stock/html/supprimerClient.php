<?php
	require_once("client.php");
	$idc=$_GET['idc'];
	client::supprimerClient($idc);
	header("location:listeClients.php");
?>