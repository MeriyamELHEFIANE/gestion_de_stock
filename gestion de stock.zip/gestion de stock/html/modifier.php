<?php
	require_once("client.php");
	extract($_POST);
	$p=new client($idc,$nom,$tel,$email,$adr);
	$p->update();
	header("location:listeClients.php");
?>