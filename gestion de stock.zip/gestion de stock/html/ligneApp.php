<?php
require_once("DAO.php");
class ligneApp{
    public $ida;
    public $ref;
    public $numApp;
    public $qteApp;
    function __construct($ida,$ref,$numApp,$qteApp){
        $this->ida=$ida;
        $this->ref=$ref;
        $this->numApp=$numApp;
        $this->qteApp=$qteApp;
    }
    function __get($prop){
        switch ($prop) {
            case 'ida':  return $this->ida;  break;
            case 'ref': return $this->ref;   break;
            case 'numApp':return $this->numApp;break;  
            case 'qteApp':return $this->qteApp;break;    
        }
    }
    function save(){
		DAO::enregistrerLignea($this->ref,$this->numApp,$this->qteApp);
	}
	static function listeLignea(){
		return DAO::listeLignea();
	}
	static function  getLignea($ida){
		return DAO::getLignea($ida);
	}
	function update(){
		DAO::modifierLignea($this->ida,$this->ref,$this->numApp,$this->qteApp);
	}
	static function  supprimerLignea($ida){
		DAO::supprimerLignea($ida);
	}
    }
    
