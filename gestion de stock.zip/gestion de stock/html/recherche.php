<?php
	require_once("produit.php");
	extract($_POST);
	$p=new produit($id,$ref,$lib,$pu,$qte,$pa,$pv,$cp);
	$p->search();
	header("location:listeProduits.php");
?>