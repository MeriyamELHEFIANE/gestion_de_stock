<?php
require_once("DAO.php");
class client{
    public $idc;
    public $nom;
    public $tel;
    public $email;
    public $adr;
    function __construct($idc,$nom,$tel,$email,$adr){
        $this->idc=$idc;
        $this->nom=$nom;
        $this->tel=$tel;
        $this->email=$email;
        $this->adr=$adr;
    }
    function __get($prop){
        switch ($prop) {
            case 'idc':  return $this->idc;  break;
            case 'nom':
                return $this->nom;
                break;
            case 'tel':
                return $this->tel;
                break;
            case 'email':
                return $this->email;
                break;
            case 'adr':
                return $this->adr;
                break;   
        }
    }
    function save(){
		DAO::enregistrerClients($this->nom,$this->tel,$this->email,$this->adr);
	}
	static function listeClients(){
		return DAO::listeClients();
	}
	static function  getClients($idc){
		return DAO::getClients($idc);
	}
	function update(){
		DAO::modifierClient($this->idc,$this->nom,$this->tel,$this->email,$this->adr);
	}
	static function  supprimerClient($idc){
		DAO::supprimerClient($idc);
	}
    }
    
